<?php
//Discuz! cache file, DO NOT modify me!
//Identify: e0bcfe57504967f4a0907e1b12191504

$pluginsetting = array (
);
?>