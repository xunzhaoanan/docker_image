<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '|P8?WsclM9&.3TN$/nx.otEA{)%?T|:4v<)r8TZwG-hx-Ga l>/[fohdjjzlwFe(' );
define( 'SECURE_AUTH_KEY',  'c[23q8`&[~:D<v.dky0q2#&ZoW$t7p+VBZx{sq0|D37lFx=#oGH(tRz}Il+68#co' );
define( 'LOGGED_IN_KEY',    ',f vCX }x=T-T0:[yDZ#Kt]u.>F,U*Imb$=JmLadTa+a!4/Bq)Ig}NT||{3PTuc)' );
define( 'NONCE_KEY',        'Fj@j~u7ZC|SrS_HUmMmdrzrV/Tmc0=mY2t5}tlV(ECqmUM+:C#5Lc_5D8z0Z!p^_' );
define( 'AUTH_SALT',        'V}U $kmR)s3|G5|=_,]&t+=sTuAJi+3U,4j(Ym;`D`aEHSGGSZ CdY55JV!JX.>I' );
define( 'SECURE_AUTH_SALT', '$9~V{`ipg6^C1mmp}nfZbS u@{+UVvP}<902PIRM9m@~`&a2yqfght_ve=Q)047%' );
define( 'LOGGED_IN_SALT',   'VaK4sD5V#5-]v]V*Pa~KcN^F%=d{Rzjz6)IdlUN{-?a{#%(l7KSXxuw$y4`/6fr#' );
define( 'NONCE_SALT',       '9{.W#<%=XW$Wbc#;9V1L*5>;Wf~#N5Mi)iF<;=h?NdN!/%6j~/ ; J2TbA=Z<ii%' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
