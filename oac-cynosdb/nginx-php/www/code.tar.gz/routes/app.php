<?php


return [
    'Test' => ['middleware' => 'sign','uses' => 'ExampleController@Test'],
//    'CreateLoadBalancer' => ['middleware' => 'sign','uses' => 'ClbController@CreateLoadBalancer'],
    'CreateLoadBalancer' => ['middleware' => 'sign','uses' => 'ClbController@CreateLoadBalancer'],
    'DescribeBlockIPList' => ['middleware' => 'sign','uses' => 'ClbController@DescribeBlockIPList'],
    'CreateListener' => ['middleware' => 'sign','uses' => 'ClbController@CreateListener'], //创建clb监听器
    'CreateRule' => ['middleware' => 'sign','uses' => 'ClbController@CreateRule'], //创建转发规则
    'ModifyListener' => ['middleware' => 'sign','uses' => 'ClbController@ModifyListener'], //修改clb监听器属性

    //CynosDB资源池检查
    'CheckCynosdbPool' => ['uses' => 'CynosdbController@CheckPool'],
    //schema分配资源
    'CreateSchema' => ['middleware' => 'sign', 'uses' => 'CynosdbController@assignSchema'],
    //schema回收资源
    'DestroySchema' => ['middleware' => 'sign', 'uses' => 'CynosdbController@unAssignSchema'],
    //schema详情
    'DescribeSchema' => ['middleware' => 'sign', 'uses' => 'CynosdbController@getSchema'],
    //集群状态
    'DescribeCluster' => ['middleware' => 'sign', 'uses' => 'CynosdbController@getCluster'],
];
