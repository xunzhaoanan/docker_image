<?php

use Illuminate\Support\Str;

return [
  'pool' => [
      [
          'cynosdb_instance_id' => 'cynosdbmysql-q2c0j6dp',
          'intranet_host' => '172.16.0.8',
          'intranet_port' => '3306',
          'internet_address' => 'gz-cynosdbmysql-grp-69y0ms63.sql.tencentcdb.com',
          'internet_port' => '26905',
      ]
  ],
  'minReserveNum' => 100,   //最小空闲数
  'maxReserveNum' => 200,   //最大空闲数
  'changeNum' => 10,        //动态伸缩数量
];