<?php

namespace App\Models;

use DateTimeInterface;

class Model extends \Illuminate\Database\Eloquent\Model
{
    public function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
