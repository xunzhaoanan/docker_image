<?php

namespace App\Models;

/**
 * Class CynosdbPool
 * @package App\Models
 * @property string $cynosdb_instance_id
 * @property string $intranet_address
 * @property string $internet_address
 * @property int $status
 */
class CynosdbDatabasePool extends Model
{
    const TABLE = 'cynosdb_database_pool';
    protected $table = self::TABLE;


    public function instanceinfo()
    {
        return $this->hasOne(CynosdbPool::class, 'cynosdb_instance_id', 'cynosdb_instance_id');
    }

}