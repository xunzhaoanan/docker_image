<?php

namespace App\Services;

use phpDocumentor\Reflection\Types\Integer;
use App\Exceptions\Services\InterfaceNotFoundException;
use Illuminate\Support\Facades\Validator;
use App\Exceptions\Services\InvalidRequestParamException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\CynosdbPool;
use App\Models\SchemaPool;
use PHPUnit\TextUI\Exception;
use Throwable;

class CynosdbServices
{

    /**
     * 同步集群
     * @return bool
     */
    public function syncCluster()
    {
        $poolConfig = config('cynosdb.pool');
        foreach ($poolConfig as $pool) {
            $poolInstanId = $pool['cynosdb_instance_id'];
            $poolInfo = CynosdbPool::query()
                ->where('cynosdb_instance_id',$poolInstanId)
                ->first();
            //如果数据库没有找到，则插入
            if (!$poolInfo) {
                DB::table(CynosdbPool::TABLE)->insert($pool);
            }
        }
        return true;
    }


    /**
     * 获取集群列表
     * @return array
     */
    public function getClusterList()
    {
        $CynosdbPools = CynosdbPool::all()->toArray();
        return $CynosdbPools;
    }


    /**
     * 选择一个集群
     * @param $platform
     * @return array
     */
    public function chooseClusterInstance($platform)
    {
        $platformList = config('platform.app');
        if (!in_array($platform,$platformList)) {
            return [false,'Platform is Invalid! '];
        }
        $cynosdbPools = CynosdbPool::all()->toArray();
        if (!$cynosdbPools) {
            Log::channel('app')->error('pool error', ['找不到Cynosdb集群']);
            return [false,'Can not find Cynosdb cluster! '];
        }
        $instanceId = $cynosdbPools[0]['cynosdb_instance_id'];
        $num = count($cynosdbPools);
        //如果实例数量大于1，则选取一个资源池空闲数量较多的
        if ($num > 1) {
            $poolCountList = SchemaPool::select(DB::raw('count(*) as cynosdb_count, cynosdb_instance_id'))
                ->where([['status', 0],['platform',$platform]])
                ->groupBy('cynosdb_instance_id')
                ->orderBy('cynosdb_count', 'DESC')
                ->get()->toArray();
            $instanceId = $poolCountList[0]['cynosdb_instance_id'];
        }
        return [true,$instanceId];
    }


    /**
     * 获取集群应用实例池
     * @param string $instanceId
     * @return bool
     */
    public function getPlatfromPool(string $instanceId)
    {
        $platformCountList = SchemaPool::select(DB::raw('count(*) as platform_count, platform'))
            ->where([['status', 0],['cynosdb_instance_id',$instanceId]])
            ->groupBy('platform')
            ->orderBy('platform_count', 'ASC')
            ->get();
        $plotformCountList = $platformCountList->toArray();
        if (!$platformCountList) {
            return false;
        }
        return $plotformCountList;
    }


    /**
     * 应用池扩容
     * @param string $instanceId
     * @param string $platform
     * @param int $changeNum
     * @return bool
     */
    public function expandPool(string $instanceId, string $platform, int $changeNum = 10)
    {
        $time = time();
        $data = [];
        $n = 0;
        for ($i=1;$i<=$changeNum;$i++){
            $random = rand(1,1000);
            $databaseName = $platform .'_'. $time . '_' . $random . '_'. $i;
            $userName = $platform .'_user_'. $time . '_' . $random . '_'. $i;
            $password = random_char(16).'!';
            $createDatabaseSql = 'CREATE DATABASE ' . $databaseName;
            $createUserSql = "CREATE USER '".$userName."'@'%' IDENTIFIED BY '".$password."';";
            $grantSql = "GRANT ALL ON ".$databaseName.".* TO '".$userName."'@'%'";

            try {
                //创建表
                DB::statement($createDatabaseSql);
                //创建用户
                DB::statement($createUserSql);
                //授权
                DB::statement($grantSql);
                //插入数据库
                $data['cynosdb_instance_id'] = $instanceId;
                $data['platform'] = $platform;
                $data['database_name'] = $databaseName;
                $data['user_name'] = $userName;
                $data['password'] = $password;
                DB::table(SchemaPool::TABLE)->insert($data);
                $n++;
            }catch (Throwable $exception){
                Log::channel('app')->error('mysql error', ['exception'=>$exception]);
                continue;
            }
        }
        Log::channel('app')->info('expand pool', ['扩容了，数量：'.$n.',执行时间：'.date('Y-m-d H:i:s')]);
        return true;
    }


    /**
     * 应用池缩容
     * @param string $instanceId
     * @param string $platform
     * @param int $changeNum
     * @return bool
     */
    public function reducePool(string $instanceId, string $platform, int $changeNum = 10)
    {
        $reduceList = SchemaPool::query()
            ->where([['status', 0],['platform',$platform]])
            ->orderBy('id', 'DESC')
            ->limit($changeNum)
            ->get()->toArray();
        if ($reduceList) {
            $n = 0;
            foreach ($reduceList as $k => $v) {
                $dropDatabaseSql = 'DROP DATABASE ' . $v['database_name'];
                $dropUserSql = "DROP USER '".$v['user_name']."'@'%'";

                try {
                    //删除表
                    DB::statement($dropDatabaseSql);
                    //删除用户
                    DB::statement($dropUserSql);
                    //删除数据库
                    $data['id'] = $v['id'];
                    DB::table(SchemaPool::TABLE)->delete($data);
                    $n++;
                }catch (Throwable $exception){
                    Log::channel('app')->error('mysql error.', ['exception'=>$exception]);
                    continue;
                }
            }
            Log::channel('app')->info('reduce pool', ['缩容了，数量：'.$n.',执行时间：'.date('Y-m-d H:i:s')]);
        }
        return true;
    }


    /**
     * 分配应用池
     * @param string $platfrom
     * @return array
     */
    public function assign(string $platfrom)
    {
        //选择一个集群
        [$chooseCode,$chooseInfo] = $this->chooseClusterInstance($platfrom);
        if (!$chooseCode) {
            return [false,$chooseInfo];
        }
        $instanceId = $chooseInfo;
        //分配资源
        $cynosdbPoolsTable = CynosdbPool::TABLE;
        $schemaTable = SchemaPool::TABLE;
        $schemaInfo = DB::table($schemaTable)
            ->leftJoin($cynosdbPoolsTable, $cynosdbPoolsTable.'.cynosdb_instance_id', '=', $schemaTable.'.cynosdb_instance_id')
            ->select($cynosdbPoolsTable.'.*',$schemaTable.'.*')
            ->where([
                [$schemaTable . '.platform', $platfrom],
                [$schemaTable . '.status', 0],
                [$schemaTable . '.cynosdb_instance_id', $instanceId],
            ])
            ->first();
        if($schemaInfo) {
            try{
                $schema_id = $this->getResourceId($schemaInfo->id);
                $affected = DB::table($schemaTable)
                    ->where('id', $schemaInfo->id)
                    ->update(['status' => 1, 'schema_id' => $schema_id]);
                $schemaInfo->schema_id = $schema_id;
                return [true,$schemaInfo];
            }catch (Throwable $exception) {
                Log::channel('app')->error('mysql error.', ['exception'=>$exception]);
                return [false,'Failed to create resource!'];
            }
        }else {
            return [false,'The pool is full!'];
        }
    }


    /**
     * 回收应用池
     * @param $schemaId
     * @return array
     */
    public function unAssign($schemaId)
    {
        $schemaInfo = SchemaPool::where('schema_id', $schemaId)->first();
        if (!$schemaInfo) {
            return [false,'Failed to find schemaId!'];
        }
        $schemaTable = SchemaPool::TABLE;
        try{
            $affected = DB::table($schemaTable)
                ->where('id', $schemaInfo->id)
                ->update(['status' => 0, 'schema_id' => "", 'uin' => ""]);
            return [true,$schemaInfo];
        }catch (Throwable $exception) {
            Log::channel('app')->error('mysql error.', ['exception'=>$exception]);
            return [false,'Failed to create resource!'];
        }
    }


    /**
     * 资源详情
     * @param $schemaId
     * @return array
     */
    public function getSchema($schemaId)
    {
        $cynosdbPoolsTable = CynosdbPool::TABLE;
        $schemaTable = SchemaPool::TABLE;
        $schemaInfo = DB::table($schemaTable)
            ->leftJoin($cynosdbPoolsTable, $cynosdbPoolsTable.'.cynosdb_instance_id', '=', $schemaTable.'.cynosdb_instance_id')
            ->select($cynosdbPoolsTable.'.*',$schemaTable.'.*')
            ->where([
                [$schemaTable . '.schema_id', $schemaId],
            ])
            ->first();
        if (!$schemaInfo) {
            return [false,'Failed to find schemaId!'];
        }
        return [true,$schemaInfo];
    }


    public function getClusterDetail()
    {
        $clusterinfo = SchemaPool::select(DB::raw('count(*) as platform_count, platform,cynosdb_instance_id,status'))
            ->groupBy(['cynosdb_instance_id','platform','status'])
            ->orderBy('platform_count', 'ASC')
            ->get();
        $clusterinfo = $clusterinfo->toArray();
        if (!$clusterinfo) {
            Log::channel('app')->error('pool error', ['找不到Cynosdb集群']);
            return [false,'Can not find Cynosdb cluster! '];
        }
        return [true,$clusterinfo];
    }


    /**
     * 生成应用池唯一id
     * @param $id
     * @param int $max
     * @return string
     */
    private function getResourceId($id, $max=6)
    {
        $time = time();
        $sn = date('Y', $time);
        $sn = substr($sn, -2);
        $sn .= date('md', $time);
        $sn .= $time;

        $len = strlen($id);
        if ($len > $max) {
            $cut = $len - $max;
            $id = substr($id, $cut);
        }

        $sn .=sprintf("%0".$max."d", $id);
        return $sn;
    }

}