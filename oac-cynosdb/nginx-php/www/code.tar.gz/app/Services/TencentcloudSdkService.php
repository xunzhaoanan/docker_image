<?php

namespace App\Services;

namespace App\Services;

require_once base_path() . '/vendor/tencentcloud-sdk/vendor/autoload.php';

use phpDocumentor\Reflection\Types\Integer;
use TencentCloud\Common\Credential;
use TencentCloud\Common\Profile\ClientProfile;
use TencentCloud\Common\Profile\HttpProfile;
use TencentCloud\Common\Exception\TencentCloudSDKException;
use TencentCloud\Clb\V20180317\ClbClient;
use TencentCloud\Clb\V20180317\Models\CreateLoadBalancerRequest;
use App\Exceptions\Services\InterfaceNotFoundException;
use Illuminate\Support\Facades\Validator;
use App\Exceptions\Services\InvalidRequestParamException;

class TencentcloudSdkService
{

    const SDK_TYPE_CLB = 'Clb';
    const SDK_TYPE_Ms = 'Ms';

    /**
     * 配置文件
     * @var array
     */
    protected array $conf;

    /**
     * 错误码
     * @var int
     */
    private int $errorCode;

    /**
     * 错误信息
     * @var string
     */
    private string $errorMessage = '';

    /**
     * 可用sdk类型
     * @var array|string[]
     */
    protected array $sdkType = ['Clb','Ms'];

    protected array $interfaceMap = [
        'Clb' => [
            'CreateLoadBalancer',
            'DescribeBlockIPList',
            'CreateListener'
        ]
    ];

    protected array $sdkNamespce = [
        'Clb' => "TencentCloud\Clb\V20180317\\"
    ];

    protected static string $endPoint;

    public function __construct()
    {
        self::$endPoint = env('CLB_ENDPOINT');
    }



    public function __call(string $action, array $params)
    {
        if (!isset($params[0]) || !in_array(ucwords($params[0]),$this->sdkType)) {
            throw new InterfaceNotFoundException($this->getService() . " does not have {$params[0]['sdkType']} type");
        }
        $sdkType = ucwords($params[0]);
        if (!in_array($action,$this->interfaceMap[$sdkType])) {
            throw new InterfaceNotFoundException($this->getService() . " does not have {$action} Interface");
        }
        return $this->doCallWithOptions($sdkType, $action, $params[1]);

    }



    protected function doCallWithOptions(string $sdkType, string $action,array $params)
    {
        //验证SecretId和SecretKey
        $data = [
            "SecretId" => isset($params['SecretId']) ? $params['SecretId'] : '',
            "SecretKey" => isset($params['SecretKey']) ? $params['SecretKey'] : '',
        ];
        $rules = [
            "SecretId" => ['string', 'required'],
            "SecretKey" => ['string', 'required']
        ];
        $validator = Validator::make($data, $rules);
        if ($validator->fails()) {
            $msg = 'Request Param Check Failed: ' . $validator->errors()->first();
//            $this->logger->error($this->getModule().' Build Request For '.$interface.' Failed', ['error'=>$msg]);
            throw new InvalidRequestParamException($msg);
        }

        //调用腾讯云sdk
        $this->conf['sercetId'] = $params['SecretId'];
        $this->conf['sercetKey'] = $params['SecretKey'];

        $cred = new Credential($this->conf['sercetId'], $this->conf['sercetKey']);

        $httpProfile = new HttpProfile();
        $httpProfile->setEndpoint(self::$endPoint);
        $clientProfile = new ClientProfile();
        $clientProfile->setHttpProfile($httpProfile);
        $region = isset($params['Region']) ? $params['Region'] : '';

        $sdkClinet = $this->sdkNamespce[$sdkType] . $sdkType . 'client';
        $client = new $sdkClinet($cred, $region, $clientProfile);
        $actionRequest = $this->sdkNamespce[$sdkType] . 'Models\\' . $action . 'Request';
        $req = new $actionRequest();
        $req->fromJsonString(json_encode($params));

        //sdk返回结果，如果有错误，需要返回到调用方法处理
        try {
            $resp = $client->$action($req);
            $resp = json_decode($resp->toJsonString(), JSON_OBJECT_AS_ARRAY);
            return $resp;
        }
        catch(TencentCloudSDKException $e)
        {
            $this->errorCode = $e->getCode();
            $this->errorMessage = $e->getMessage();
            return false;
        }
    }



    public function getService(): string
    {
        return get_class($this);
    }

    public function getErrorCode(): Integer
    {
        return $this->errorCode;
    }

    public function getErrorMessage(): string
    {
        return $this->errorMessage;
    }



}