<?php

namespace App\Exceptions\Services;


use App\Support\ErrorCode;
use Throwable;

class InvalidRequestParamException extends ServicesException
{
    public function __construct($message = "", $code = ErrorCode::INTERFACE_INVALID_REQUEST_PARAMS, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}