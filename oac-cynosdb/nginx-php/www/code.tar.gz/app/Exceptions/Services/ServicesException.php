<?php

namespace App\Exceptions\Services;

use App\Support\ErrorCode;
use Exception;
use Throwable;

class ServicesException extends Exception
{
    public function __construct($message = "", $code = ErrorCode::MODULE_ERROR, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
