<?php

namespace App\Exceptions;

use App\Support\ErrorCode;
use Exception;
use Throwable;

class InvalidRequestParamException extends Exception
{
    public function __construct($message = "", $code = ErrorCode::COMMON_ERROR, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }

    public function getStatusCode(): int
    {
        return 400;
    }
}
