<?php

namespace App\Logging;

use App\Http\Request\Request;
use Monolog\Logger;
use Monolog\Processor\IntrospectionProcessor;

class AppLogger
{
    public function __invoke($logger)
    {
        /*
         * 添加附加参数到日志中
         */
        # Processors
        $logger->pushProcessor(new IntrospectionProcessor(Logger::DEBUG, ['Illuminate\\']));
        $logger->pushProcessor(
            function ($record) {
                /** @var Request $request */
                $request = app('request');
                $record['extra']['clientIP'] = $request->getClientIp();
                $record['extra']['requestId'] = '';

                if($request instanceof Request) {
                    $record['extra']['requestId'] = $request->getRequestId();
                }
                return $record;
            });
    }
}
