<?php

namespace App\Logging;

use App\Http\Request\Request;

class AccessLogger
{
    public function __invoke($logger)
    {
        $logger->pushProcessor(
            function ($record) {
                /** @var Request $request */
                $request = app(Request::class);
                $record['extra']['requestId'] = $request->getRequestId();
                $record['extra']['clientIP'] = $request->getClientIp();

                return $record;
            });
    }
}
