<?php

namespace App\Http\Controllers;

use App\Services\TencentcloudSdkService;
use App\Http\Request\AppRequest as Request;
use App\Http\Response\AppResponse as Response;
use App\Exceptions\Services\InterfaceNotFoundException;
use App\Exceptions\Services\ServicesException;
use Illuminate\Support\Facades\Log;


class ExampleController extends Controller
{

    public function Test(Request $request)
    {
        $n = 1;
        $host = 'localhost';
        $data = [];
        for ($i=$n,$k=0;$i<101;$i++,$k++) {
            $name = 'oc_major'.$i;
            $data[$k]['AccountName'] = $name;
            $data[$k]['Host'] = $host;
        }
        pr(json_encode($data));

    }





}