<?php

namespace App\Http\Controllers;

use App\Exceptions\InvalidRequestParamException;
use App\Support\ErrorCode;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Laravel\Lumen\Routing\Controller as BaseController;
use Psr\Log\LoggerInterface;

class Controller extends BaseController
{
    protected LoggerInterface $logger;

    //
    public function __construct()
    {
        $this->logger = Log::channel('app');
    }

    /**
     * @param array $params
     * @param array $rules
     * @param string $callerClass
     * @param string $callerMethod
     * @throws InvalidRequestParamException
     */
    public function validateRequestParams(array $params, array $rules, string $callerClass = '', string $callerMethod = '')
    {
        $validator = Validator::make($params, $rules);
        if (!$validator->fails()) return;
        $message = $validator->errors()->first();
        $message = sprintf('params check failed, reason: %s', $message);
        throw new InvalidRequestParamException($message, ErrorCode::REQUEST_ERROR);
    }

    /**
     * @param Builder|EloquentBuilder $query
     * @param array $requestParams
     * @param array|string[] $columns
     * @return LengthAwarePaginator
     */
    protected function paginateQuery($query, array $requestParams, array $columns = ['*']): LengthAwarePaginator
    {
        $pageSize = min($requestParams['pageSize'] ?? 50, 50);
        return $query->paginate($pageSize, $columns, 'curPage');
    }

    /**
     * @param Builder|EloquentBuilder $query
     * @param array $requestParams
     * @param array $acceptableKeys
     * @return Builder|EloquentBuilder
     */
    protected function withConditions($query, array $requestParams, array $acceptableKeys = [])
    {
        foreach ($requestParams as $k => $v) {
            if (empty($v)) continue;
            if (!empty($acceptableKeys) && !in_array($k, $acceptableKeys)) continue;
            $cond = $this->parseRequestCond($k, $v);
            if ($cond) {
                $cond[0] = Str::snake($cond[0]);
                $query = is_array($v) ? $query->whereIn(...$cond) : $query->where(...$cond);
            }
        }
        return $query;
    }

    private function parseRequestCond(string $key, $value): ?array
    {
        if (in_array($key, ['pageSize', 'curPage'])) return null;
        if (is_array($value)) {
            $key = Str::endsWith($key, 'List') ? substr($key, 0, -4) : $key;
            return [$key, $value];
        }
        if (Str::endsWith($key, 'Start')) {
            return [substr($key, 0, -5), '>=', $value];
        }
        if (Str::endsWith($key, 'End')) {
            return [substr($key, 0, -3), '<', $value];
        }
        if (Str::endsWith($key, 'Like')) {
            return [substr($key, 0, -4), 'like', "%{$value}%"];
        }
        return [$key, '=', $value];
    }
}
