<?php

namespace App\Http\Controllers;

use App\Services\TencentcloudSdkService;
use App\Http\Request\AppRequest as Request;
use App\Http\Response\AppResponse as Response;
use App\Exceptions\Services\InterfaceNotFoundException;
use App\Exceptions\Services\ServicesException;
use Illuminate\Support\Facades\Log;


class ClbController extends Controller
{

    public object $sdkService;

    public function __construct()
    {
        $this->sdkService = app(TencentcloudSdkService::class);
    }

    public function DescribeBlockIPList(Request $request)
    {
        $params = $request->getParams();
        $response = $this->sdkService->DescribeBlockIPList(TencentcloudSdkService::SDK_TYPE_CLB,$params);
        if (!$response) {
            throw new ServicesException($this->sdkService->getErrorMessage());
        }
//        pr($response);
    }


    /**
     * 购买clb
     * @param Request $request
     * @return \App\Http\Response\Response
     * @throws ServicesException
     */
    public function CreateLoadBalancer(Request $request)
    {
        $params = $request->getParams();
        $response = $this->sdkService->CreateLoadBalancer(TencentcloudSdkService::SDK_TYPE_CLB,$params);
        if (!$response) {
            throw new ServicesException($this->sdkService->getErrorMessage());
        }
        $data['LoadBalancerIds'] = $response['LoadBalancerIds'][0];
        return Response::success($request, $data);
    }


    public function CreateListener(Request $request)
    {

        $params = $request->getParams();
        $response = $this->sdkService->CreateListener(TencentcloudSdkService::SDK_TYPE_CLB,$params);
        if (!$response) {
            throw new ServicesException($this->sdkService->getErrorMessage());
        }

        $data['ListenerIds'] = $response['ListenerIds'][0];
        return Response::success($request, $data);
    }



}