<?php

namespace App\Http\Controllers;

use App\Support\ErrorCode;
use App\Services\CynosdbServices;
use App\Http\Request\AppRequest as Request;
use App\Http\Response\AppResponse as Response;
use Illuminate\Validation\Rule;
use App\Exceptions\Services\InterfaceNotFoundException;
use App\Exceptions\Services\ServicesException;
use App\Services\TencentcloudSdkService;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\CynosdbPool;
use App\Models\CynosdbDatabasePool;


class CynosdbController extends Controller
{
    /**
     * 容器池检查
     * @param Request $request
     * @return \App\Http\Response\Response
     */
    public function CheckPool(Request $request)
    {
        $cynosdbServices = app(CynosdbServices::class);
        /** @var CynosdbServices $cynosdbServices */

        //同步集群实例
        $cynosdbServices->syncCluster();
        //获取集群
        $clusterList = $cynosdbServices->getClusterList();

        //检查资源
        $platformList = config('platform.app');
        $minReserveNum = config('cynosdb.minReserveNum');
        $maxReserveNum = config('cynosdb.maxReserveNum');
        $changeNum = config('cynosdb.changeNum');
        foreach ($clusterList as $culster) {
            $instanceId = $culster['cynosdb_instance_id'];
            $platformPoolList = $cynosdbServices->getPlatfromPool($instanceId);
            if (!$platformPoolList) {
                //初始化资源池
                foreach ($platformList as $platformK => $platformV) {
                    //扩容
                    $cynosdbServices->expandPool($instanceId, $platformV, $changeNum);
                }
            } else {
                $platformPoolList = keyToArray($platformPoolList, 'platform');
                foreach ($platformList as $platformK => $platformV) {
                    if (!isset($platformPoolList[$platformV])) {
                        //扩容
                        $cynosdbServices->expandPool($instanceId, $platformV, $changeNum);
                    } elseif ($platformPoolList[$platformV]['platform_count'] <= $minReserveNum) {
                        //扩容
                        $cynosdbServices->expandPool($instanceId, $platformV, $changeNum);
                    } elseif ($platformPoolList[$platformV]['platform_count'] > $maxReserveNum) {
                        //缩容
                        $cynosdbServices->reducePool($instanceId, $platformV, $changeNum);
                    }
                }
            }
        }
        return Response::success($request, [
            'checkResult' => 'ok',
        ]);
    }


    /**
     * 分配资源
     * @param Request $request
     * @return \App\Http\Response\Response
     * @throws \App\Exceptions\InvalidRequestParamException
     */
    public function assignSchema(Request $request)
    {
        $params = $request->getParams();
        $rules = [
            'Platfrom' => ['required', 'string'],
//            'Uin' => ['required', 'int'],
        ];
        $this->validateRequestParams($params, $rules, __CLASS__, __METHOD__);

        $cynosdbServices = app(CynosdbServices::class);
        /** @var CynosdbServices $cynosdbServices */
        [$resultCode, $resultInfo] = $cynosdbServices->assign($params['Platfrom']);
        if (!$resultCode) {
            return Response::fail($request, $resultInfo, ErrorCode::COMMON_ERROR);
        }
        return Response::success($request, [
            'SchemaId' => (string)$resultInfo->schema_id,
//            'Uin' => $resultInfo->uin,
            'Platform' => $resultInfo->platform,
            'IntranetHost' => $resultInfo->intranet_host,
            'IntranetPort' => $resultInfo->intranet_port,
            'InternetHost' => $resultInfo->internet_host,
            'InternetPort' => $resultInfo->internet_port,
            'DatabaseName' => $resultInfo->database_name,
            'UserName' => $resultInfo->user_name,
            'Password' => $resultInfo->password,
        ]);
    }


    /**
     * 回收资源
     * @param Request $request
     * @return \App\Http\Response\Response
     * @throws \App\Exceptions\InvalidRequestParamException
     */
    public function unAssignSchema(Request $request)
    {
        $params = $request->getParams();
        $rules = [
            'SchemaId' => ['required', 'string'],
        ];
        $this->validateRequestParams($params, $rules, __CLASS__, __METHOD__);

        $cynosdbServices = app(CynosdbServices::class);
        /** @var CynosdbServices $cynosdbServices */
        [$resultCode, $resultInfo] = $cynosdbServices->unAssign($params['SchemaId']);
        if (!$resultCode) {
            return Response::fail($request, $resultInfo, ErrorCode::COMMON_ERROR);
        }
        return Response::success($request, [
            'SchemaId' => (string)$resultInfo->schema_id,
        ]);
    }


    /**
     * 资源详情
     * @param Request $request
     * @return \App\Http\Response\Response
     * @throws \App\Exceptions\InvalidRequestParamException
     */
    public function getSchema(Request $request)
    {
        $params = $request->getParams();
        $rules = [
            'SchemaId' => ['required', 'string'],
        ];
        $this->validateRequestParams($params, $rules, __CLASS__, __METHOD__);
        $cynosdbServices = app(CynosdbServices::class);
        /** @var CynosdbServices $cynosdbServices */
        [$resultCode, $resultInfo] = $cynosdbServices->getSchema($params['SchemaId']);
        if (!$resultCode) {
            return Response::fail($request, $resultInfo, ErrorCode::COMMON_ERROR);
        }
        return Response::success($request, [
            'SchemaId' => (string)$resultInfo->schema_id,
            'Uin' => $resultInfo->uin,
            'Platform' => $resultInfo->platform,
            'IntranetHost' => $resultInfo->intranet_host,
            'IntranetPort' => $resultInfo->intranet_port,
            'InternetHost' => $resultInfo->internet_host,
            'InternetPort' => $resultInfo->internet_port,
            'DatabaseName' => $resultInfo->database_name,
            'UserName' => $resultInfo->user_name,
            'Password' => $resultInfo->password,
        ]);
    }


    /**
     * 获取集群详情
     * @param Request $request
     * @return \App\Http\Response\Response
     */
    public function getCluster(Request $request)
    {
        $cynosdbServices = app(CynosdbServices::class);
        /** @var CynosdbServices $cynosdbServices */
        [$resultCode, $resultInfo] = $cynosdbServices->getClusterDetail();
        $clusterList = $cynosdbServices->getClusterList();
        if (!$resultCode) {
            return Response::fail($request, $resultInfo, ErrorCode::COMMON_ERROR);
        }

        foreach ($clusterList as $k => $v) {
            $n = 0;
            $m = 0;
            $used = [];
            $free = [];
            foreach ($resultInfo as $key => $value) {
                $data['ClusterInfo'][$k]['InstanceId'] = $v['cynosdb_instance_id'];
                if ($v['cynosdb_instance_id'] == $value['cynosdb_instance_id']) {
                    if ($value['status'] == 1) {
                        $used[$n]['Platform'] = $value['platform'];
                        $used[$n]['PlatformCount'] = $value['platform_count'];
                        $n++;
                    }else {
                        $free[$m]['Platform'] = $value['platform'];
                        $free[$m]['PlatformCount'] = $value['platform_count'];
                        $m++;
                    }
                }
            }
            $data['ClusterInfo'][$k]['StatusInfo']['used']['SchemaInfo'] = $used;
            $data['ClusterInfo'][$k]['StatusInfo']['free']['SchemaInfo'] = $free;

        }
        return Response::success($request, $data);

    }

}