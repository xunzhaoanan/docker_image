<?php

namespace App\Http\Request;

use Illuminate\Support\Str;

class AppRequest extends Request
{
    protected function actionField(): string
    {
        return 'Action';
    }

    protected function parseRequestId(): ?string
    {
        return trim($this->input('RequestId', Str::uuid()));
    }

    protected function parseUin(): ?string
    {
        return trim($this->input('SubAccountUin'));
    }

    protected function parseOwnerUin(): ?string
    {
        return trim($this->input('Uin'));
    }

    protected function parseParams(): ?array
    {
        return $this->all();
    }
}
