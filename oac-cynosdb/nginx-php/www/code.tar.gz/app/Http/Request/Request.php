<?php

namespace App\Http\Request;

use App\Support\ErrorCode;
use Illuminate\Http\Request as BaseRequest;
use Illuminate\Support\Arr;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

abstract class Request extends BaseRequest
{
    protected string $actionField;

    protected string $action;
    protected ?string $requestId;
    protected ?string $uin;
    protected ?string $ownerUin;
    protected ?array $params;



    public function parse()
    {
        $this->actionField = $this->actionField();
        $this->action = $this->parseAction();
        $this->requestId = $this->parseRequestId();
        $this->uin = $this->parseUin();
        $this->ownerUin = $this->parseOwnerUin();
        $this->params = $this->parseParams();
    }

    private function parseAction(): string
    {
        if(empty($this->input($this->actionField))) {
            $jsonBody = json_decode($this->getContent(), true);
            $this->merge($jsonBody ?? []);
        }
        $action = trim($this->input($this->actionField));
        if(empty($action)) {
            throw new BadRequestHttpException(
                'Cannot Parse Request Action Field:'.$this->actionField,
                null,
                ErrorCode::INVALID_REQUEST
            );
        }
        return $action;
    }

    abstract protected function actionField(): string;
    abstract protected function parseRequestId(): ?string;
    abstract protected function parseUin(): ?string;
    abstract protected function parseOwnerUin(): ?string;
    abstract protected function parseParams(): ?array;

    public function getAction(): string
    {
        return $this->action;
    }

    public function getRequestId(): string
    {
        return $this->requestId;
    }

    public function getParams(): array
    {
        return $this->params;
    }

    public function getParam(string $key, $default = null)
    {
        return Arr::get($this->params, $key, $default);
    }
    /**
     * @return string
     */
    public function getOwnerUin(): string
    {
        return $this->ownerUin;
    }

    /**
     * @return string
     */
    public function getUin(): string
    {
        return $this->uin;
    }
}