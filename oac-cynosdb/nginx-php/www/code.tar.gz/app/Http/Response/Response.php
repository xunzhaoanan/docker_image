<?php

namespace App\Http\Response;

use App\Http\Request\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Throwable;

abstract class Response extends \Illuminate\Http\Response
{
    /**
     * @param Request $request
     * @param array|string $data
     * @param int $code
     * @param int $statusCode
     * @param array $headers
     * @return Response
     */
    public static function success(Request $request, array $data, $code = 0, int $statusCode = 200, array $headers = [])
    {
        return (new static)->setStatusCode($statusCode)
            ->withHeaders($headers)
            ->setContent(static::formatData($request, $code, $data));
    }

    /**
     * @param Request $request
     * @param string $message
     * @param $code
     * @param int $statusCode
     * @param array $headers
     * @return Response
     */
    public static function fail(Request $request, string $message, $code, int $statusCode = 200, array $headers = [])
    {
        return (new static)->setStatusCode($statusCode)
            ->withHeaders($headers)
            ->setContent(static::formatErrorMessage($request, $code, $message));
    }

    public static function handleException(Request $request, Throwable $exception)
    {
        $statusCode = 500;
        $message = $exception->getMessage();
        $returnCode = static::getReturnCode($exception);
        $shortClassName = explode('\\', get_class($exception));
        $shortClassName = end($shortClassName);
        if (method_exists($exception, 'getStatusCode')) {
            $statusCode = $exception->getStatusCode();
        } elseif (method_exists(Response::class, 'handle' . $shortClassName)) {
            list($statusCode, $message) = call_user_func(Response::class.'::handle' . $shortClassName, $exception);
        }
        return static::fail($request, $message, $returnCode, $statusCode);
    }

    protected static function handleModelNotFoundException(ModelNotFoundException $exception): array
    {
        $statusCode = 404;
        $message = 'cannot find ' . $exception->getModel() . ' with conditions:';
        $conds = $exception->getTrace()[1]['args'][0] ?? [];
        $message = $message . json_encode($conds, JSON_UNESCAPED_SLASHES);
        return [$statusCode, $message];
    }

    abstract static protected function getReturnCode(Throwable $exception);

    abstract static protected function formatData(Request $request, $code, array $data);

    abstract static protected function formatErrorMessage(Request $request, $code, string $message): array;
}
