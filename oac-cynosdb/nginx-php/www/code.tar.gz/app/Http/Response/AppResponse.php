<?php

namespace App\Http\Response;

use App\Http\Request\Request;
use App\Support\ErrorCode;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Throwable;

class AppResponse extends Response
{
    const ERR_INVALID_PARAMETER = 'InvalidParameter';
    const ERR_INTERNAL_ERROR = 'InternalError';
    const ERR_RESOURCE_NOT_FOUND = 'ResourceNotFound';
    const ERR_FAILED_OPTION = 'FailedOption';

    static public function fail(Request $request, string $message, $code, int $statusCode = 200, array $headers = [])
    {
        return parent::fail($request, $message, $code, 200, $headers);
    }

    static protected function formatData(Request $request, $code, array $data = []): array
    {
        return [
            'Response'=>array_merge(['RequestId' => $request->getRequestId()], $data)
        ];
    }

    static protected function formatErrorMessage(Request $request, $code, string $message): array
    {
        return [
            'Response' => [
                'Error' => [
                    'Code' => is_numeric($code) ? self::translateErrorCode($code) : $code,
                    'Message' => $message,
                ],
//                'RequestId' => $request->getRequestId()
            ]
        ];
    }

    static protected function getReturnCode(Throwable $exception)
    {
        if($exception instanceof ModelNotFoundException) {
            return self::ERR_RESOURCE_NOT_FOUND;
        }
        return self::ERR_INTERNAL_ERROR;
    }

    static private function translateErrorCode($innerErrorCode)
    {
        switch ($innerErrorCode) {
            case ErrorCode::INTERFACE_INVALID_REQUEST_PARAMS:
                return self::ERR_INVALID_PARAMETER;
            default:
                return self::ERR_INTERNAL_ERROR;
        }
    }
}