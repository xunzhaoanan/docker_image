<?php

if (!function_exists('keyToArray')) {
    function keyToArray(array $arr, string $key): array
    {
        $data = [];
        foreach ($arr as $k => $v) {
            $data[$v[$key]] = $v;
        }
        return $data;
    }
}


if (!function_exists('random_char')) {
    function random_char($length = 10,$chars = null){
        if( empty($chars) ){
            $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        }
        $chars = str_shuffle($chars);
        $num = $length < strlen($chars) - 1 ? $length:str_len($chars) - 1;
        $str = substr($chars,0,$num);
        $str = ucfirst($str);
        return $str;
    }
}


if (!function_exists('logPath')) {
    /**
     * 获取日志目录
     *
     * @param string|null $subPath
     * @return string
     */
    function logPath(string $subPath = null): string
    {
        return storage_path('logs' . ($subPath ? '/' . $subPath : ''));
    }
}

if (!function_exists('inProduction')) {
    /**
     * 判断是否处于现网环境
     *
     * @return bool
     */
    function inProduction(): bool
    {
        return 'production' === env('app.env', 'dev');
    }
}

if(!function_exists('columnPrefix')) {
    function columnPrefix(string $tableName, $column)
    {
        if(is_array($column)) {
            return array_map(function ($v) use ($tableName) {
                return $tableName.'.'.$v;
            }, $column);
        }
        return $tableName.'.'.$column;
    }
}

if (!function_exists('arrayKeysTransform')) {
    function arrayKeysTransform(array $arr, callable $transformer, array $exceptKeys = []): array
    {
        foreach ($arr as $k => $v) {
            if (in_array($k, $exceptKeys, true)) {
                continue;
            }
            unset($arr[$k]);
            $k = $transformer($k);
            if (is_array($v)) {
                $v = arrayKeysTransform($v, $transformer, $exceptKeys);
            }
            $arr[$k] = $v;
        }
        return $arr;
    }
}

if(!function_exists('lcfirstArrayKeys')) {
    function lcfirstArrayKeys(array $arr): array
    {
        return arrayKeysTransform($arr, 'lcfirst');
    }
}

if(!function_exists('ucfirstArrayKeys')) {
    function ucfirstArrayKeys(array $arr): array
    {
        return arrayKeysTransform($arr, 'ucfirst');
    }
}

if(!function_exists('arrayKeysToSnake')) {
    function arrayKeysToSnake(array $params, array $exceptKeys = []): array
    {
        return arrayKeysTransform($params, [\Illuminate\Support\Str::class, 'snake'], $exceptKeys);
    }
}

if (!function_exists('arrayKeysToCamel')) {
    function arrayKeysToCamel(array $params, array $exceptKeys = []): array
    {
        return arrayKeysTransform($params, [\Illuminate\Support\Str::class, 'camel'], $exceptKeys);
    }
}

if (!function_exists('bitwiseInclude')) {
    function bitwiseInclude(int $needle, int $haystack) {
        return $haystack>0 && $needle>0 && ($needle & $haystack) === $needle;
    }
}

if(!function_exists('bitwiseEncode')) {
    /**
     * 用位计算算出表达代表组合情况的值
     * @param array $flagNameSet
     * @param array $flagNameDict
     * @return int
     */
    function bitwiseEncode(array $flagNameSet, array $flagNameDict): int
    {
        $result = 0;
        foreach ($flagNameSet as $flagName) {
            if(!isset($flagNameDict[$flagName])) continue;
            $result = $result | intval($flagNameDict[$flagName]);
        }
        return $result;
    }
}

if(!function_exists('bitwiseDecode')) {
    function bitwiseDecode(int $flagValue, array $flagNameDict): array
    {
        $result = [];
        foreach ($flagNameDict as $k => $v) {
            (((int)$v & $flagValue) === (int)$v) && $result[] = $k;
        }
        return $result;
    }
}

if (!function_exists('trimStrings')) {
    function trimStrings(array $data, array $except = []): array
    {
        return valuesTransform($data, 'trim', $except);
    }
}

if(!function_exists('arrayPick')) {
    function arrayPick(array $haystack, array $keys): ?array
    {
        return array_intersect_key($haystack, array_flip($keys));
    }
}

if (!function_exists('valuesTransform')) {
    /**
     * 指定转换函数，转换字符串类型的值
     *
     * @param array $arr
     * @param callable $transformer
     * @param array $exceptKeys
     * @return array
     */
    function valuesTransform(array $arr, callable $transformer, array $exceptKeys = []): array
    {
        foreach ($arr as $k => $v) {
            if (in_array($k, $exceptKeys, true)) {
                continue;
            }
            if (is_array($v)) {
                $v = valuesTransform($v, $transformer, $exceptKeys);
            } elseif (is_string($v)) {
                $v = $transformer($v);
            }
            $arr[$k] = $v;
        }
        return $arr;
    }
}

if (!function_exists('turnEmptyStringToNull')) {
    function turnEmptyStringToNull(array $arr, array $exceptKeys = []): array
    {
        return valuesTransform($arr, fn ($value) => empty($value) ? null : $value, $exceptKeys);
    }
}
