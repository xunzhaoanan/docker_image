<?php

namespace App;

use App\Concerns\RoutesRequests;
use App\Http\Request\Request;
use Laravel\Lumen\Application as LumenApplication;
use Symfony\Component\HttpFoundation\Request as SymfonyRequest;

class Application extends LumenApplication
{
    use RoutesRequests;

    /**
     * @param string $namespace
     * @param array $routes
     */
    public function setRoute(string $namespace = 'App\Http\Controllers', array $routes = [])
    {
        $this->router->group(
            ['namespace' => $namespace],
            function ($router) use ($routes) {
                foreach ($routes as $k => $r) {
                    $router->post($k, $r);
                }
            });
    }

    /**
     * Prepare the given request instance for use with the application.
     *
     * @param  \Symfony\Component\HttpFoundation\Request $request
     * @return \App\Http\Request\Request
     */
    protected function prepareRequest(SymfonyRequest $request)
    {
        parent::prepareRequest($request);
        if (! $request instanceof Request) {
            $concrete = $this->getAlias(Request::class);
            $request = call_user_func([$concrete, 'createFromBase'], $request);
        }
        return $request;
    }
}
