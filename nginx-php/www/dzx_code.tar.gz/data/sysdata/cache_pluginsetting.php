<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 5e1d0159dfa119c3aec67ec4f0366d6a

$pluginsetting = array (
);
?>