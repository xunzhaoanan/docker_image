<?php


namespace App\Api\Controller\Users;


class WechatQyLoginController extends AbstractWechatQyLoginController
{
    public $type = 'wechatqy';
}
