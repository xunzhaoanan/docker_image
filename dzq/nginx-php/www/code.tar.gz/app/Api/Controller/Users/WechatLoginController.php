<?php

/**
 * Discuz & Tencent Cloud
 * This is NOT a freeware, use is subject to license terms
 */

namespace App\Api\Controller\Users;

class WechatLoginController extends AbstractWechatLoginController
{
   public $type = 'wechat';
}
