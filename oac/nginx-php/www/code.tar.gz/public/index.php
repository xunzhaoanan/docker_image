<?php

/*
|--------------------------------------------------------------------------
| Create The Application
|--------------------------------------------------------------------------
|
| First we need to get an application instance. This creates an instance
| of the application / container and bootstraps the application so it
| is ready to receive HTTP / Console requests from the environment.
|
*/

ini_set('display_errors',1);
error_reporting(E_ALL);

function pr( $var = 9) {
    $template = php_sapi_name() !== 'cli' ? '<pre>%s</pre>' : "\n%s\n" ;
    printf( $template, print_r( $var, true ) ) ;
    exit();
}
/** @var App\Application $app */
$app = require __DIR__.'/../bootstrap/app.php';

//$app->register(\App\Providers\AppPaginationServiceProvider::class);

/*
|--------------------------------------------------------------------------
| Run The Application
|--------------------------------------------------------------------------
|
| Once we have the application, we can handle the incoming request
| through the kernel, and send the associated response back to
| the client's browser allowing them to enjoy the creative
| and wonderful application we have prepared for them.
|
*/

$routes = require __DIR__.'/../routes/app.php';
$app->setRoute('App\Http\Controllers', $routes);
$app->alias( App\Http\Request\Request::class,Illuminate\Http\Request::class);
$app->alias(App\Http\Request\AppRequest::class, App\Http\Request\Request::class);
$app->run();
