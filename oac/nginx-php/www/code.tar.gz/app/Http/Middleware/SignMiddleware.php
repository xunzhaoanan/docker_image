<?php

namespace App\Http\Middleware;

use Closure;
use App\Support\ErrorCode;
use App\Http\Response\AppResponse as Response;

class SignMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $params = $request->input();
        if (is_string($params)) {
            $params = json_decode($params,true);
        }

        if (!self::checkSign($params)) {
            $message = 'The provided credentials could not be validated. Please check your signature is correct.';
            return Response::fail($request, $message, ErrorCode::SIGN_ERROR);
        }
        return $next($request);
    }


    /**
     * 生成加密字符串
     * @param array $params 合并请求的GET数组和POST数组
     * @param string $signKey 约定的加密key
     * @return string 加密结果字符串
     */
    private static function checkSign($params)
    {
        if (!isset($params['Sign'])) {
            return false;
        }
        //请求端sign
        $sign = $params['Sign'];
        $signKey = env('SIGNKEY');
        $preString = self::makePreString($params, $signKey);
        //服务端sign
        $serverSign = md5($preString);
        if ($sign !== $serverSign) {
            return false;
        }
        return true;
    }


    /**
     * 获取加密前待加密的字符串
     * @param array $params 合并请求的GET数组和POST数组
     * @param string $signKey 约定的加密key
     * @return string 待加密字符串
     */
    private static function makePreString($params, $signKey)
    {
        $params['Sign_key'] = $signKey;
        $params = self::filterParams($params);
        // 按参数键名排序参数
        ksort($params);
        // 参数连接方式：age=12&name=张三&sex=male
        $preString = urldecode(http_build_query($params));
        return $preString;
    }

    /**
     * 过滤参数值
     * @param array $params
     * @return array
     */
    private static function filterParams($params = [])
    {
        $filtered = array_filter(
            $params,
            function ($value, $key) {
            // 排除空值
            if (in_array($value, ['', null, false], true)) {
                return false;
            }
             // 排除不参与加密的参数
             if (in_array($key, ['Sign'])) {
                 return false;
             }
             return true;
            },
            ARRAY_FILTER_USE_BOTH
            );
        return $filtered;
    }

}
