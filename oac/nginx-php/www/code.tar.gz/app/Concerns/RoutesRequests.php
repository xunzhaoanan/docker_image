<?php

namespace App\Concerns;

use FastRoute\Dispatcher;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use Laravel\Lumen\Concerns\RoutesRequests as LumenRoutesRequests;
use Symfony\Component\HttpFoundation\Request as SymfonyRequest;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Laravel\Lumen\Http\Request as LumenRequest;

trait RoutesRequests
{
    use LumenRoutesRequests;

    /**
     * Parse the incoming request and return the method and path info.
     *
     * @param SymfonyRequest|null $request
     * @return array
     */
    protected function parseIncomingRequest($request)
    {
        $isNewRequest = false;
        if (!$request) {
            $request = LumenRequest::capture();
            $isNewRequest = true;
        }
        $request = $this->prepareRequest($request);
        $this->instance(get_class($request), $request);
        $request->parse();
        if ($isNewRequest) {
            Log::channel('access')->info(
                'Request',
                [
                    'method' => $request->method(),
                    'uri' => $request->getRequestUri(),
                    'action' => $request->getAction(),
                    'body' => $request->getContent()
                ]
            );
        }
        return [$request->getMethod(), '/' . $request->getAction()];
    }

    /**
     * Dispatch the incoming request.
     *
     * @param SymfonyRequest|null $request
     * @return Response
     */
    public function dispatch($request = null)
    {
        $response = parent::dispatch($request);
        Log::channel('access')->info(
            'Response',
            [
                'body' => $response->getContent(),
                'statusCode' => $response->getStatusCode()
            ]
        );
        return $response;
    }

    /**
     * Handle the response from the FastRoute dispatcher.
     *
     * @param array $routeInfo
     * @return mixed
     */
    protected function handleDispatcherResponse($routeInfo)
    {
        switch ($routeInfo[0]) {
            case Dispatcher::NOT_FOUND:
                throw new NotFoundHttpException("Cannot Find Action:" . app()->make('request')->getAction(), null);
            case Dispatcher::METHOD_NOT_ALLOWED:
                throw new MethodNotAllowedHttpException($routeInfo[1]);
            case Dispatcher::FOUND:
                return $this->handleFoundRoute($routeInfo);
        }
    }
}
