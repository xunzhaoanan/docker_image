<?php

namespace App\Models;

/**
 * Class CynosdbPool
 * @package App\Models
 * @property string $cynosdb_instance_id
 * @property string $intranet_address
 * @property string $internet_address
 * @property int $status
 */
class CynosdbPool extends Model
{
    const TABLE = 'cynosdb_pool';
    protected $table = self::TABLE;

}