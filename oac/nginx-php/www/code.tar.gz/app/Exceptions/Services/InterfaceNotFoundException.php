<?php

namespace App\Exceptions\Services;

use App\Support\ErrorCode;
use Throwable;

class InterfaceNotFoundException extends ServicesException
{
    public function __construct($message = "", $code = ErrorCode::INTERFACE_NOT_FOUND, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}