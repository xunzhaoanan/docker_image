<?php

use Illuminate\Support\Str;

return [
    'app' => ['wordpress','discuzx','discuzq','nextcloud']
];