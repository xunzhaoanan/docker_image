<?php

return [
    'default' => env('LOG_CHANNEL', 'app'),
    'channels' => [
        'app' => [
            'driver' => 'daily',
            'name' => 'app',
            'path' => storage_path('logs/oac.log'),
            'tap' => [App\Logging\AppLogger::class],
            'level' => 'debug',
            'days' => 14,
            'permission' => 0664,
            'formatter' => Monolog\Formatter\JsonFormatter::class,
        ],
        'access' => [
            'name' => 'access',
            'driver' => 'daily',
            'path' => storage_path('logs/oac.log'),
            'tap' => [App\Logging\AccessLogger::class],
            'level' => 'debug',
            'days' => 14,
            'permission' => 0664,
            'formatter' => Monolog\Formatter\JsonFormatter::class,
        ]
    ]
];
