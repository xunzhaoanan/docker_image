<?php namespace Config;

use CodeIgniter\Config\BaseConfig;

class Learn extends BaseConfig
{
    public $templateDir = '/onetouch_template/';   //模板目录
    public $workDir = '/onetouch_work/';   //工作目录
    public $siteIdWord = '{{site_id}}';   //应用id通配符
    public $workDirWord = '{{work_dir}}';   //工作目录通配符
    public $domain = 'onetouch.com';   //工作目录通配符
    public $deploymentName = 'deployment';   //deployment名称
    public $serviceName = 'service';   //service名称
    public $ingressName = 'ingress';   //ingress名称
    public $programRange = ['dzx','wordpress']; //应用数组
}