<?php

namespace App\Controllers;

class Learn extends BaseController {

    /**
     * 体验站应用配置参数，如需修改，请前往app\config\learn.php
     * @var mixed
     */
    public $learnConfig;

    /**
     * 模板目录，每个应用不同
     * @var
     */
    public $templateDir;

    /**
     * 工作目录,k8s实例需要挂载的目录，每次实例化一个新的应用会创建一个
     * @var
     */
    public $workDir;

    /**
     * 域名
     * @var
     */
    public $domain;

    /**
     * 应用id通配符
     * @var
     */
    public $siteIdWord;

    /**
     * 工作目录通配符
     * @var
     */
    public $workDirWord;

    /**
     * deployment名称
     * @var
     */
    public $deploymentName;

    /**
     * service名称
     * @var
     */
    public $serviceName;

    /**
     * ingress名称
     * @var
     */
    public $ingressName;

    public function __construct()
    {
        $this->learnConfig = config('Config\\Learn');
        foreach ($this->learnConfig as $confKey => $confValue) {
            $this->$confKey = $confValue;
        }
    }


    public function index()
    {
//        echo phpinfo();exit;
        return view('learn.html');
    }


    /**
     * 创建pod，生成体验站
     */
    public function create()
    {
        helper('file');
        $programType = $this->request->getGet('program');   //应用类型
        $programId = $this->request->getGet('id');    //应用id

        if (!$programType || !$programId) {
            die(json_encode('缺少参数：program，id'));
        }

        //判断应用范围
        if (!in_array($programType,$this->learnConfig->programRange)) {
            die(json_encode('该应用不存在'));
        }
        $workDir = $this->workDir.$programType . '_' .$programId;
        $targetDomain = $programId .'.'. $programType .'.'. $this->domain;
        //判断是否已经创建该应用
        if (!is_dir($workDir)) {
            //创建目标文件夹
            if (!mkdir($workDir)) {
                die(json_encode('创建文件夹失败'));
            }
        }else {
            die(json_encode('该应用已创建，地址为：'.$targetDomain));
        }

        //复制模板文件
        $programDir = $this->templateDir.$programType;
        dir_copy($programDir,$workDir);

        //替换yaml
        $yamlDir = $workDir .'/yaml/';
        $yamlFile = $yamlDir.$programType.'.yaml';
        // chmod($yamlFile,0777);
        $yaml = file_get_contents($yamlFile);
        $yaml = str_replace($this->siteIdWord,$programId,$yaml);    //替换应用id
//        $yaml = str_replace($this->workDirWord,$workDir,$yaml); //替换工作目录

        //通过ingress的yaml增加转发规则
        $ingressYamlFile = $this->templateDir .'/lb_ingress.yaml';
        $ingressYaml = file_get_contents($ingressYamlFile);
        $ingressArr = yaml_parse($ingressYaml); //转换yaml为arr
        $serviceName = $programType .'-'. $this->serviceName .'-'. $programId;

        //新增httprule
        $httpInsertRule = self::getHttpInsertRule($targetDomain,$serviceName);
        $httpRule = json_decode($ingressArr['metadata']['annotations']['kubernetes.io/ingress.http-rules'],true);
        array_push($httpRule,$httpInsertRule);
        $httpRule = json_encode($httpRule,JSON_UNESCAPED_SLASHES);
        $ingressArr['metadata']['annotations']['kubernetes.io/ingress.http-rules'] = $httpRule;

        //新增rule
        $insertRule = self::getInsertRule($targetDomain,$serviceName);
        array_push($ingressArr['spec']['rules'],$insertRule);
        //把数组转化回yaml
        $ingressYaml = yaml_emit($ingressArr);

        //写入yaml
        file_put_contents($yamlFile,$yaml);
        file_put_contents($ingressYamlFile,$ingressYaml);

        //执行k8s命令
        
        exec('kubectl apply -f '.$yamlFile,$out,$return_status);
        exec('kubectl apply -f '.$ingressYamlFile,$out,$return_status);

        die(json_encode('建站成功，体验网址：'.$targetDomain));


    }


    /**
     * 删除pod，销毁一个体验站
     */
    public function delete()
    {
        helper('file');
        $programType = $this->request->getGet('program');   //应用类型
        $programId = $this->request->getGet('id');    //应用id

        if (!$programType || !$programId) {
            die(json_encode('缺少参数：program，id'));
        }

        //判断应用范围
        if (!in_array($programType,$this->learnConfig->programRange)) {
            die(json_encode('该应用不存在'));
        }
        //判断是应用是否还存在
        $workDir = $this->workDir.$programType . '_' .$programId;
        if (!is_dir($workDir)) {
            die(json_encode('目标已不存在'));
        }

        //删除工作文件夹
        if (!dir_del($workDir)) {
            die(json_encode('删除文件夹失败'));
        }

        //k8s销毁命令，目前需要销毁deployment，service和ingress
        $deploymentName = $programType .'-'. $this->deploymentName .'-'. $programId;
        $serviceName = $programType .'-'. $this->serviceName .'-'. $programId;
        $ingressName = $programType .'-'. $this->ingressName .'-'. $programId;
        //执行deployment删除命令
        exec('kubectl delete deploy '.$deploymentName,$out,$return_status);
        //执行service删除命令
        exec('kubectl delete service '.$serviceName,$out,$return_status);
        //执行ingress删除命令
//        exec('kubectl delete ingress '.$ingressName,$out,$return_status);

        //通过ingress的yaml删除转发规则
        $ingressYamlFile = $this->templateDir .'/lb_ingress.yaml';
        $ingressYaml = file_get_contents($ingressYamlFile);
        $ingressArr = yaml_parse($ingressYaml); //转换yaml为arr
        $targetDomain = $programId .'.'. $programType .'.'. $this->domain;  //目标地址
        $serviceName = $programType .'-'. $this->serviceName .'-'. $programId; //目标svc

        //删除httprule
        $httpRule = json_decode($ingressArr['metadata']['annotations']['kubernetes.io/ingress.http-rules'],true);
        foreach ($httpRule as $httpRuleK => $httpRuleV) {
            if ($httpRuleV['host'] == $targetDomain) {
                unset($httpRule[$httpRuleK]);
            }
        }
        $httpRule = json_encode($httpRule,JSON_UNESCAPED_SLASHES);
        $ingressArr['metadata']['annotations']['kubernetes.io/ingress.http-rules'] = $httpRule;

        //删除rule
        $rule = $ingressArr['spec']['rules'];
        foreach ($rule as $ruleK => $ruleV) {
            if ($ruleV['host'] == $targetDomain) {
                unset($rule[$ruleK]);
            }
        }
        $ingressArr['spec']['rules'] = $rule;

        //把数组转化回yaml
        $ingressYaml = yaml_emit($ingressArr);

        //写入yaml
        file_put_contents($ingressYamlFile,$ingressYaml);

        die(json_encode('目标网站：【'.$targetDomain.'】 已销毁'));

    }


    private static function getHttpInsertRule($targetDomain,$serviceName)
    {
        $httpInsertRule = [
            'host' => $targetDomain,
            'path' => "/",
            'backend' => [
                'serviceName' => $serviceName,
                'servicePort' => 80
            ]
        ];
        return $httpInsertRule;
    }

    private static function getInsertRule($targetDomain,$serviceName)
    {
        $insertRule = [
            'host' => $targetDomain,
            'http' => [
                'paths' => [
                    [
                        'backend' => [
                            'serviceName' => $serviceName,
                            'servicePort' => 80
                        ],
                        'path' => "/"
                    ]
                ]
            ]
        ];
        return $insertRule;
    }
}