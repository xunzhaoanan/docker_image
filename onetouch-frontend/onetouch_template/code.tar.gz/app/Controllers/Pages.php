<?php
namespace App\Controllers;
class Pages extends BaseController {

    public function view()
    {
        pr($this->request->getGet('bbb'));
    }
}