<?php

echo phpinfo();
